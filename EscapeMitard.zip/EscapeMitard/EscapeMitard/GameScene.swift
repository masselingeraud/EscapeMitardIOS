//
//  GameScene.swift
//  EscapeMitard
//
//  Created by Geraud Masselin on 02/03/2017.
//  Copyright © 2017 Geraud Masselin. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var player :  SKSpriteNode?
    var background : SKSpriteNode?
    var background2 : SKNode?
    var timeLabel : SKLabelNode?
    var metre = 0
    
    
    override func didMove(to view: SKView)
    {
        
        if let mitard = childNode(withName: "//Mitard") as? SKSpriteNode
        {
            player  = mitard
        }
        
        if let backgame = childNode(withName: "//BackGame") as? SKSpriteNode
        {
            background = backgame
        }
        
        if let backgame2 = childNode(withName: "//BackGame2")
        {
            background2 = backgame2
        }
        
        if let timer = childNode(withName: "//TimeLabel") as? SKLabelNode{
            timeLabel = timer
        }
        
        let moveUp = SKAction.moveBy(x: 0, y: 50, duration: 1)
        let moveReset = SKAction.moveBy(x: 0, y: -50, duration: 0)
        let moveLoop = SKAction.sequence([moveUp, moveReset])
        let moveForever = SKAction.repeatForever(moveLoop)
        
        background2?.run(moveForever)
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (Timer) in
            self.metre += 1
            self.timeLabel?.text = "\(self.metre)"
            
            
        }
    

    }
    
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        
    
        
      
        
      
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let point = touches.first?.location(in: self )
        {
            player?.position = point
        }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
  
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
